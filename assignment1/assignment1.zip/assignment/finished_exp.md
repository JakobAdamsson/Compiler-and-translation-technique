Finished with:
- Type
- VarDeclaration
- Identifier
- Expression(almost (Expression "." Identifier "(" ( Expression ( "," Expression )* )? ")"))


# Ask
x.length  
x < 5 || y < 5 && 5*5==25