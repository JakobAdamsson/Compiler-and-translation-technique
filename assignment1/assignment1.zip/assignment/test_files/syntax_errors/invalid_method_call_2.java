public class Factorial{
    public static void main(String[] a){
        System.out.println(new Fac().ComputeFac(10));
    }
}

class Element {
    public boolean Init(){
        int test;

        // test = this.Bar(a,);
        test = this.Bar(,a);
        System.out.println(test);
        return false;
    }

    public int Bar(int a, boolean b){
        return 1;
    }
}
