public class Factorial{
    public static void main(String[] a){
        System.out.println(new Element().Init());
    }
}

class Element {
    public boolean Init(){
        int test;
        test = v_Age ;        
    }
}
