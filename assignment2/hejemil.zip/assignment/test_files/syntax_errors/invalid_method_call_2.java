public class Factorial{
    public static void main(String[] a){
        System.out.println(new Element().Init());
    }
}

class Element {
    public boolean Init(){
        int test;

        test = this.Bar(,a);
        return false;
    }

    public int Bar(int a, boolean b){
        return 1;
    }
}
